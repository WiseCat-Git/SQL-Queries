/*
Title: Count of vin with annual subscription with(out) autorenew
Author: David Garcia
Description: This query answers the question "What percentage of annual subscribers are subscribed to annual auto renew vs. annual non-auto renew? ", optional to include the demo data
Last updated date: 10/11/2023
Update log
- 10/11/2023: changed brand logic, added year and free trial flag 
- 9/04/2023: Title and description added into the file.
*/

 
select 
  year(cast(substring(sus.termstartdate, 1, 10) as date)) as Yeartermstartdate
  , month(cast(substring(sus.termstartdate, 1, 10) as date)) as Monthtermstartdate
  , upper(case when upper(vinmodel2) = 'WAGONEER' THEN vinmodel2 when n_brnd = 'J' then 'JEEP' when n_brnd = 'R' then 'RAM' when n_brnd = 'W' then 'WAGONEER' else COALESCE(N_brnd, Vinmake) end) as brand 
  , Currenttermperiodtype
  , Currentterm
  , case when n_cmpgn_seg like '%3%' or (u.x_offer_versn_desc = 'GSDP INTRO (1D)' and cast(substring(u.cntct_date, 1, 10) as date) >= cast('2022-08-25' as date)) then '3+3 free trial' else '6 month trial' end as free_trial_flag
  , count(DISTINCT case when Autorenew = 'true' then sus.vin end) vinCountAR 
  , count(DISTINCT case when Autorenew = 'false' then sus.vin end) vinCountNonAR
from fca_src_prd.sf_gsdp_ignite_v_subscription sus
inner join fca_src_prd.sf_gsdp_ignite_v_vehicleprofile vp on sus.vin = vp.vin
left join service_marketing_reporting.uconnect_gsdp_cntct_hist u on concat(i_vin_first_9, i_vin_last_8) = vp.vin
where cast(substring(sus.termstartdate, 1, 10) as date) between cast ('2023-01-01' as date) and cast ('2023-09-30' as date)--------------check dates first-------------------------------------------
and sus.productcode in ('NA_Assistance_Opt', 'NA_Navigation_Opt', 'NA_Assist+Navigation_Opt')
and cast(currentterm as int) = 12
group by year(cast(substring(sus.termstartdate, 1, 10) as date)) 
  , month(cast(substring(sus.termstartdate, 1, 10) as date))
  , upper(case when upper(vinmodel2) = 'WAGONEER' THEN vinmodel2 when n_brnd = 'J' then 'JEEP' when n_brnd = 'R' then 'RAM' when n_brnd = 'W' then 'WAGONEER' else COALESCE(N_brnd, Vinmake) end)
  , Currenttermperiodtype
  , Currentterm
  , case when n_cmpgn_seg like '%3%' or (u.x_offer_versn_desc = 'GSDP INTRO (1D)' and cast(substring(u.cntct_date, 1, 10) as date) >= cast('2022-08-25' as date)) then '3+3 free trial' else '6 month trial' end 
order by year(cast(substring(sus.termstartdate, 1, 10) as date)) 
  , month(cast(substring(sus.termstartdate, 1, 10) as date))
  , upper(case when upper(vinmodel2) = 'WAGONEER' THEN vinmodel2 when n_brnd = 'J' then 'JEEP' when n_brnd = 'R' then 'RAM' when n_brnd = 'W' then 'WAGONEER' else COALESCE(N_brnd, Vinmake) end)
  , Currenttermperiodtype
  , Currentterm