/*
Title: Growth rate query 
Author: David Garcia
Description: This query returns the growth, count of cancellations and new subscriptions by year, month, brand
Last updated date: 11/23/2023
Update log
- 11/23/2023: added the active subscriptions count
- 10/25/2023: changed the productcode condition to only includes the currently required
- 10/6/2023: added a new version based that also counts by month, the cancelled subscriptions and the new subscrptions
- 10/3/2023: added a new version based on the subscription historical table
- 9/13/2023: added the filter to show only the months that ended before the current date
- 9/12/2023: Title and description added into the file.
*/

with sus_historical as(
select
    cast(substring(sus.termstartdate, 1, 10) as date) as tsd,
    cast(substring(COALESCE(PostCanTermenddate, suscan.termenddate, sus.termenddate), 1, 10) as date) as ted,
    cast(substring(sus.termenddate, 1, 10) as date) as realted,
    cast(case when sus.currentterm = 'null' then '0' else sus.currentterm end as int) as currentterm,
    upper(u.N_brnd) as brand,
    sus.status,
    trim(sus.vin) as vin
from fca_src_prd.sf_gsdp_ignite_v_subscription_history sus
left join service_marketing_reporting.uconnect_gsdp_cntct_hist u on sus.vin = concat(u.i_vin_first_9, u.i_vin_last_8)
left join (select subscriptionnumber, termenddate, DATE_ADD(Currenttermperiodtype, cast(currentterm as int), cast(substring(termenddate, 1, 10) as date)) as postTermEndDate from fca_src_prd.sf_gsdp_ignite_v_subscription_history where status = 'Cancelled' and productcode like '%Opt' and (productcode like '%Assist%' or productcode like '%Navigation%')) 
    susCan on sus.subscriptionnumber = susCan.subscriptionnumber
left join (select subscriptionnumber, termenddate as PostCanTermenddate, max(cast(substring(termenddate, 1, 10) as date)) termenddate from fca_src_prd.sf_gsdp_ignite_v_subscription_history where productcode like '%Opt' and (productcode like '%Assist%' or productcode like '%Navigation%') group by subscriptionnumber, termenddate)
    as susPostCan on sus.subscriptionnumber = susPostCan.subscriptionnumber and susCan.postTermEndDate <= susPostCan.termenddate
where (productcode = 'NA_Assistance_Opt' or productcode = 'NA_Navigation_Opt' or productcode = 'NA_Assist+Navigation_Opt' )
    and upper(u.N_brnd) in ('JEEP', 'RAM', 'DODGE','WAGONEER')
	  and cast(substring(sus.termstartdate, 1, 10) as date) < DATE_TRUNC('month', current_Date)
)
, dateData as(
select distinct
    year(tsd) DataYear
    , month(tsd) DataMonth
    , DATE_TRUNC('month', tsd) FirstofMonth
    , last_day_of_month(tsd) LastofMonth
from sus_historical
)
select 
    DataYear
    , DataMonth
    , brand
    , count(distinct case when tsd < ted and (FirstofMonth between TSD and TED or LastofMonth between TSD and TED) then vin end) as GrowthCount
    , count(distinct case when status = 'Cancelled' and FirstofMonth = DATE_TRUNC('month', realted) then vin end) as CancelledCount
    , count(distinct case when tsd < ted and FirstofMonth = DATE_TRUNC('month', tsd) then vin end) as NewSubsCount
    , count(distinct case when tsd < ted and (FirstofMonth between TSD and TED or LastofMonth between TSD and TED) and status = 'Active' then vin end) as ActiveSubsCount
from dateData
cross join sus_historical
group by 
    DataYear
    , DataMonth
    , brand
order by 
    DataYear
    , DataMonth
    , brand
	
----------------------------------------------------------Version 2 (deprecated)
with sus_historical as(
select
    cast(substring(sus.termstartdate, 1, 10) as date) as tsd,
    cast(substring(COALESCE(PostCanTermenddate, suscan.termenddate, sus.termenddate), 1, 10) as date) as ted,
    cast(substring(sus.termenddate, 1, 10) as date) as realted,
    cast(case when sus.currentterm = 'null' then '0' else sus.currentterm end as int) as currentterm,
    upper(u.N_brnd) as brand,
    sus.status,
    trim(sus.vin) as vin
from fca_src_prd.sf_gsdp_ignite_v_subscription_history sus
left join service_marketing_reporting.uconnect_gsdp_cntct_hist u on sus.vin = concat(u.i_vin_first_9, u.i_vin_last_8)
left join (select subscriptionnumber, termenddate, DATE_ADD(Currenttermperiodtype, cast(currentterm as int), cast(substring(termenddate, 1, 10) as date)) as postTermEndDate from fca_src_prd.sf_gsdp_ignite_v_subscription_history where status = 'Cancelled' and productcode like '%Opt' and (productcode like '%Assist%' or productcode like '%Navigation%')) 
    susCan on sus.subscriptionnumber = susCan.subscriptionnumber
left join (select subscriptionnumber, termenddate as PostCanTermenddate, max(cast(substring(termenddate, 1, 10) as date)) termenddate from fca_src_prd.sf_gsdp_ignite_v_subscription_history where productcode like '%Opt' and (productcode like '%Assist%' or productcode like '%Navigation%') group by subscriptionnumber, termenddate)
    as susPostCan on sus.subscriptionnumber = susPostCan.subscriptionnumber and susCan.postTermEndDate <= susPostCan.termenddate
where sus.productcode like '%Opt'
    and (sus.productcode like '%Assist%' or sus.productcode like '%Navigation%')
    and upper(u.N_brnd) in ('JEEP', 'RAM', 'DODGE','WAGONEER')
	  and cast(substring(sus.termstartdate, 1, 10) as date) < DATE_TRUNC('month', current_Date)
)
, dateData as(
select distinct
    year(tsd) DataYear
    , month(tsd) DataMonth
    , DATE_TRUNC('month', tsd) FirstofMonth
    , last_day_of_month(tsd) LastofMonth
from sus_historical
)
select 
    DataYear
    , DataMonth
    , brand
    , count(distinct case when tsd < ted and (FirstofMonth between TSD and TED or LastofMonth between TSD and TED) then vin end) as GrowthCount
    , count(distinct case when status = 'Cancelled' and FirstofMonth = DATE_TRUNC('month', realted) then vin end) as CancelledCount
    , count(distinct case when tsd < ted and FirstofMonth = DATE_TRUNC('month', tsd) then vin end) as NewSubsCount
    , count(distinct case when tsd < ted and (FirstofMonth between TSD and TED or LastofMonth between TSD and TED) then vin end) - count(distinct case when tsd < ted and FirstofMonth = DATE_TRUNC('month', tsd) then vin end) as NewSubsDiff
from dateData
cross join sus_historical
group by 
    DataYear
    , DataMonth
    , brand
order by 
    DataYear
    , DataMonth
    , brand

----------------------------------------------------------Version 1 (deprecated)

with susCTE as(
select
    year(cast(substring(sus.termstartdate, 1, 10) as date)) as Yeartsd,
    month(cast(substring(sus.termstartdate, 1, 10) as date)) as Monthtsd,
    case when month(cast(substring(sus.termstartdate, 1, 10) as date)) > 1 then year(cast(substring(sus.termstartdate, 1, 10) as date)) else year(cast(substring(sus.termstartdate, 1, 10) as date)) - 1 end as prevYearTSD,
    case when month(cast(substring(sus.termstartdate, 1, 10) as date)) > 1 then month(cast(substring(sus.termstartdate, 1, 10) as date)) - 1 else 12 end as prevMonthTSD,
    case when n_cmpgn_seg like '%3%' or (u.x_offer_versn_desc = 'GSDP INTRO (1D)' and cast(substring(cntct_date, 1, 10) as date) >= cast('2022-08-25' as date)) then '3+3 free trial' else '6 month trial' end as free_trial_flag,
    sus.productcode,
    cast(case when sus.currentterm = 'null' then '0' else sus.currentterm end as int) as currentterm,
    upper(u.N_brnd) as brand,
    count(sus.vin) as vinCount
from fca_src_prd.sf_gsdp_ignite_v_subscription sus
inner join service_marketing_reporting.uconnect_gsdp_cntct_hist u on sus.vin = concat(u.i_vin_first_9, u.i_vin_last_8)
where sus.productcode like '%Opt'
    and (sus.productcode like '%Assist%' or sus.productcode like '%Navigation%')
    and upper(u.N_brnd) in ('JEEP', 'RAM', 'DODGE','WAGONEER')
	and cast(substring(sus.termstartdate, 1, 10) as date) < DATE_TRUNC('month', current_Date)
group by year(cast(substring(sus.termstartdate, 1, 10) as date)),
    month(cast(substring(sus.termstartdate, 1, 10) as date)),
    case when month(cast(substring(sus.termstartdate, 1, 10) as date)) < 12 then year(cast(substring(sus.termstartdate, 1, 10) as date)) else year(cast(substring(sus.termstartdate, 1, 10) as date)) + 1 end,
    case when month(cast(substring(sus.termstartdate, 1, 10) as date)) < 12 then month(cast(substring(sus.termstartdate, 1, 10) as date)) + 1 else 1 end,
    sus.productcode,
    cast(case when sus.currentterm = 'null' then '0' else sus.currentterm end as int),
    upper(u.N_brnd),
    case when n_cmpgn_seg like '%3%' or (u.x_offer_versn_desc = 'GSDP INTRO (1D)' and cast(substring(cntct_date, 1, 10) as date) >= cast('2022-08-25' as date)) then '3+3 free trial' else '6 month trial' end
)
  select susCTE.Yeartsd
  , susCTE.Monthtsd
  , suscte.Brand
  , susCTE.productcode
  , susCTE.currentterm
  , suscte.free_trial_flag
  , susCTE.VinCount
  , susCTE2.VinCount as prevMonthVinCount
  , case when susCTE2.VinCount is null then null else cast((susCTE.VinCount - susCTE2.VinCount) as double)/cast(susCTE2.VinCount as double) end as GrowthRate
from susCTE
left join susCTE as susCTE2
    on suscte.prevYearTSD = susCTE2.yeartsd
    and suscte.prevmonthTSD = susCTE2.monthtsd
    and susCTE.productcode = susCTE2.productcode
    and susCTE.currentterm = susCTE2.currentterm
    and suscte.Brand = suscte2.brand
    and suscte.free_trial_flag = susCTE2.free_trial_flag
order by
    susCTE.Yeartsd
    , susCTE.Monthtsd
    , suscte.Brand
    , susCTE.productcode
    , susCTE.currentterm
    , suscte.free_trial_flag