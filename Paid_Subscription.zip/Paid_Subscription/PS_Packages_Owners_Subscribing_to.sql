
/*
Title: Packages subscription by package type
Author: David Garcia
Description: This query answers the questions "What packages are owners subscribing to? assistance only vs. navigation only vs. assist+nav joint", optional to include the demo data
Last updated date: 10/18/2023
Update log
- 10/18/2023: checked query logic
- 10/11/2023: changed brand logic, added year and free trial flag 
- 9/04/2023: Added the package NA_Assist+Navigation_Opt, added a comment to check the date range before running
- 8/28/2023: Title and description added into the file.
*/

with sourceCTE as (
select distinct 
  year(cast(substring(sus.termstartdate, 1, 10) as date)) as Yeartermstartdate
  , month(cast(substring(sus.termstartdate, 1, 10) as date)) as Monthtermstartdate
  , upper(case when n_brnd = 'J' then 'JEEP' when n_brnd = 'R' then 'RAM' when n_brnd = 'W' then 'WAGONEER' else COALESCE(N_brnd, Vinmake) end) as brand
  , case when n_cmpgn_seg like '%3%' or (u.x_offer_versn_desc = 'GSDP INTRO (1D)' and cast(substring(u.cntct_date, 1, 10) as date) >= cast('2022-08-25' as date)) then '3+3 free trial' else '6 month trial' end as free_trial_flag
  , case when sus.productcode = 'NA_Assistance_Opt' or sus.productcode = 'NA_Assist+Navigation_Opt' then 'X' end as HasAssistance
  , case when sus.productcode = 'NA_Navigation_Opt' or sus.productcode = 'NA_Assist+Navigation_Opt' then 'X' end as HasNavigation
  , sus.vin
from fca_src_prd.sf_gsdp_ignite_v_subscription sus
inner join fca_src_prd.sf_gsdp_ignite_v_vehicleprofile vp on sus.vin = vp.vin
left join service_marketing_reporting.uconnect_gsdp_cntct_hist u on sus.vin = concat(i_vin_first_9, i_vin_last_8) 
where cast(substring(sus.termstartdate, 1, 10) as date) between cast ('2023-01-01' as date) and cast ('2023-09-30' as date) --check the right date range before running
and sus.productcode in ('NA_Assistance_Opt', 'NA_Navigation_Opt', 'NA_Assist+Navigation_Opt')
)
, groupCTE as (
select 
  vin
  , Yeartermstartdate
  , Monthtermstartdate
  , brand
  , free_trial_flag
  , count(case when HasAssistance = 'X' and HasNavigation is null then 1 end) as Assistance
  , count(case when HasNavigation = 'X' and HasAssistance is null then 1 end) as Navigation
from sourceCTE
  group by vin
  , Yeartermstartdate
  , Monthtermstartdate
  , brand
  , free_trial_flag)
select 
  Yeartermstartdate
  , Monthtermstartdate
  , brand
  -- , free_trial_flag
  , count(distinct case when Assistance = 1 and Navigation = 0 then groupCTE.vin end) OnlyAssistance
  , count(distinct case when Assistance = 0 and Navigation = 1 then groupCTE.vin end) OnlyNavigation
  , count(distinct case when Assistance = 1 and Navigation = 1 then groupCTE.vin end) AssistancePlusNavigation 
from groupCTE
group by Yeartermstartdate, Monthtermstartdate
  -- , free_trial_flag
  , brand
order by Yeartermstartdate, Monthtermstartdate
  -- , free_trial_flag
  , brand
