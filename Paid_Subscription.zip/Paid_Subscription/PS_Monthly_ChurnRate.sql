/*
Title: Churn rate query 
Author: David Garcia
Description: This query returns the churn rate and trend by year, month, brand, free trial flag, package type and current term
Last updated date: 10/25/2023
Update log
- 10/25/2023: changed the productcode condition to only includes the currently required
- 9/13/2023: Title and description added into the file, added the filter to show only the months that ended before the current date
*/

with susCTE as (
select 
  year(cast(substring(sus.termstartdate, 1, 10) as date)) as yearTSD
  , month(cast(substring(sus.termstartdate, 1, 10) as date)) as monthTSD
  , cast(concat(substring(sus.termstartdate, 1, 8), '01') as date) as ParamDate
  , substring(sus.termstartdate, 1, 7) as yearMonthParam
  , cast(substring(sus.termstartdate, 1, 10) as date) as TSD
  , cast(substring(sus.termenddate, 1, 10) as date) as TED
  , case when u.n_cmpgn_seg like '%3%' or (u.x_offer_versn_desc = 'GSDP INTRO (1D)' and cast(substring(u.cntct_date, 1, 10) as date) >= cast('2022-08-25' as date)) then '3+3 free trial' else '6 month trial' end as free_trial_flag
  , sus.productcode
  , cast(case when sus.currentterm = 'null' then '0' else sus.currentterm end as int) as currentterm
  , upper(u.N_brnd) as brand
  , sus.vin
from fca_src_prd.sf_gsdp_ignite_v_subscription sus
inner join service_marketing_reporting.uconnect_gsdp_cntct_hist u on sus.vin = concat(u.i_vin_first_9, u.i_vin_last_8)
where (productcode = 'NA_Assistance_Opt' or productcode = 'NA_Navigation_Opt' or productcode = 'NA_Assist+Navigation_Opt' )
and upper(u.N_brnd) in ('JEEP', 'RAM', 'DODGE','WAGONEER')
and cast(substring(sus.termstartdate, 1, 10) as date) < DATE_TRUNC('month', current_Date))
, dateSelection as 
(
  select distinct yearTSD, monthTSD, ParamDate, yearMonthParam
  from susCTE
)
select
  dateSelection.yearTSD as yearParam
  , dateSelection.monthTSD as monthParam
  , dateSelection.yearMonthParam
  , free_trial_flag
  , productcode
  , currentterm
  , brand
  , count(distinct case when dateSelection.ParamDate between TSD and TED then vin end) as SOMSubs
  , count(distinct case when last_day_of_month(dateSelection.ParamDate) between TSD and TED then vin end) as EOMSubs
  , case when count(distinct case when dateSelection.ParamDate between TSD and TED then vin end) = 0 then 0 else cast(count(distinct case when dateSelection.ParamDate between TSD and TED then vin end) - count(distinct case when last_day_of_month(dateSelection.ParamDate) between TSD and TED then vin end) as double)/cast(count(distinct case when dateSelection.ParamDate between TSD and TED then vin end) as double) end as CR_1
  , case when count(distinct case when last_day_of_month(dateSelection.ParamDate) between TSD and TED then vin end) = 0 then 0 else cast(count(distinct case when last_day_of_month(dateSelection.ParamDate) between TSD and TED then vin end) - count(distinct case when dateSelection.ParamDate between TSD and TED then vin end) as double)/cast(count(distinct case when last_day_of_month(dateSelection.ParamDate) between TSD and TED then vin end) as double) end as CR_2

from susCTE
cross join dateSelection --on susCTE.yearTSD = dateSelection.yearTSD and susCTE.monthTSD = dateSelection.monthTSD
group by dateSelection.yearTSD
  , dateSelection.monthTSD
  , dateSelection.yearMonthParam
  , free_trial_flag
  , productcode
  , currentterm
  , brand
order by dateSelection.yearTSD
  , dateSelection.monthTSD
  , free_trial_flag
  , productcode
  , currentterm
  , brand