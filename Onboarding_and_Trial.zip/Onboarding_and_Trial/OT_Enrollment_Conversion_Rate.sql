/*
Title: Business question OT - Row 4
Author: David Garcia
Description: This query answers the question "How many owners who started their trial as unenrolled/ disabled are ending their trial fully enrolled? (i.e. What's is our enrollment conversion at the end of 90 days, per the benchmark? Report out monthly)
   - What is our enrollment conversion at the end of the 90 days from lite enrolled to fully enrolled? 
   - What is our enrollment conversion at the end of the 90 days from NULL (unenrolled)  to fully enrolled?
   - What is our enrollment conversion at the end of the 90 days from services disabled to fully enrolled?"
Last updated date: 8/30/2023
Update log
- 8/30/2023: brand is now coming from the camp comm table, deleted the segment type filter, added the brand filter, all the 1D that are sent since 8/25/2023 are flagged as 3+3 free trial
- 8/28/2023: Title and description added into the file
*/

with u as 
(
  select case when STRPOS(Term_start_date,'-') > 0 then cast(substring(Term_start_date,1,10) as date) else date_parse(substring(Term_start_date,1,10),'%c/%d/%Y') end as term_start_date
  , case when STRPOS(Term_end_date,'-') > 0 then cast(substring(Term_end_date,1,10) as date) else date_parse(substring(Term_end_date,1,10),'%c/%d/%Y') end as term_end_date
  , case when STRPOS(cntct_date,'-') > 0 then cast(substring(cntct_date,1,10) as date) else date_parse(substring(cntct_date,1,10),'%c/%d/%Y') end as cntct_date
  , x_offer_versn_desc
  , c_creatv_versn
  , enroll_status
  , service_type
  , concat(i_vin_first_9, i_vin_last_8) as vin
  , n_cmpgn_seg
  , upper(n_brnd) as Brand
  from service_marketing_reporting.uconnect_gsdp_cntct_hist
  where trim(cntct_date) > '' and trim(Term_start_date) > ''
)
select 
year(u.cntct_date) Contact_date_year
, month(u.cntct_date) Contact_date_month --Cadence based on the contact date
, case when n_cmpgn_seg like '%3%' or (u.x_offer_versn_desc = 'GSDP INTRO (1D)' and u.cntct_date >= cast('2022-08-25' as date)) then '3+3 free trial' else '6 month trial' end as free_trial_flag --Free trial flag
, u.brand
, count(distinct case when u.x_offer_versn_desc in ('1A/B CONNECTIVITY INTRO','INTRO ADHOC')
  and u.c_creatv_versn in ('CA286','CA287','CA284')
  and u.enroll_status = 'enrolled'
  then u.vin end) as count_enrolled --Count of VIN that started they free trial as enrolled
, count(distinct case when u.x_offer_versn_desc in ('1C CONNECTIVITY INTRO','INTRO ADHOC')
  and u.c_creatv_versn in ('CA285','CA288')
  and u.enroll_status = 'notenrolled'
  then u.vin end) as count_unenrolled --Count of VIN that started they free trial as unenrolled
, count(distinct case when u.x_offer_versn_desc in ('1C CONNECTIVITY INTRO','INTRO ADHOC')
  and u.c_creatv_versn in ('CA285','CA288')
  and u.enroll_status = 'notenrolled'
  and cast(substring(vp.activationdate, 1, 10) as date) between u.term_start_date and u.term_end_date
  and vp.activationtype = 'FULL REGISTRATION'
  then u.vin end) as count_unenrolled_converted --Count of VIN that started they free trial as unenrolled, which were converted un full enrolled on the period of time of their free trial
, count(distinct case when u.x_offer_versn_desc in ('GSDP INTRO (1D)')
  and u.c_creatv_versn in ('CA288')
  and u.enroll_status = 'notenrolled'
  then u.vin end) as count_disabled --Count of VIN that started they free trial as services disabled
, count(distinct case when u.x_offer_versn_desc in ('GSDP INTRO (1D)')
  and u.c_creatv_versn in ('CA288')
  and u.enroll_status = 'notenrolled'
  and cast(substring(vp.activationdate, 1, 10) as date) between u.term_start_date and u.term_end_date
  and vp.activationtype = 'FULL REGISTRATION'
  then u.vin end) as count_disabled_converted --Count of VIN that started they free trial as services disabled, which were converted un full enrolled on the period of time of their free trial
from u
left join fca_src_prd.sf_gsdp_ignite_v_vehicleprofile vp on u.vin = vp.vin
where u.brand in ('JEEP', 'DODGE', 'RAM', 'WAGONEER')
group by year(u.cntct_date) 
, month(u.cntct_date) 
, case when n_cmpgn_seg like '%3%' or (u.x_offer_versn_desc = 'GSDP INTRO (1D)' and u.cntct_date >= cast('2022-08-25' as date)) then '3+3 free trial' else '6 month trial' end
, u.brand
order by year(u.cntct_date) 
, month(u.cntct_date) 
, case when n_cmpgn_seg like '%3%' or (u.x_offer_versn_desc = 'GSDP INTRO (1D)' and u.cntct_date >= cast('2022-08-25' as date)) then '3+3 free trial' else '6 month trial' end
, u.brand