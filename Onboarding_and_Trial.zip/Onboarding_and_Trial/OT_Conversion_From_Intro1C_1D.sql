/*
Title: enrollment conversions query
Author: David Garcia
Description: This query returns of the number of who received 1C and 1D emails, how many became full registration
Last updated date: 8/28/2023
Update log
- 8/28/2023: Title and description added into the file. 
*/


with u as (
select case when STRPOS(Term_end_date,'-') > 0 then cast(substring(Term_end_date,1,10) as date) else date_parse(substring(Term_end_date,1,10),'%c/%d/%Y') end as term_end_date
  , case when STRPOS(cntct_date,'-') > 0 then cast(substring(cntct_date,1,10) as date) else date_parse(substring(cntct_date,1,10),'%c/%d/%Y') end as cntct_date
  , service_type
  , concat(i_vin_first_9, i_vin_last_8) as vin
  , upper(n_brnd) as brand
  , case 
    when n_cmpgn_seg like '%3%' and n_cmpgn_seg like '%DISABLED%' then 'Disabled 3+3'
    when n_cmpgn_seg like '%DISABLED%' then 'Disabled'
    when n_cmpgn_seg like '%3%' then '3+3 free trial' else '6 month trial' end as freetrialflag
  from service_marketing_reporting.uconnect_gsdp_cntct_hist
  where trim(Term_end_date) > ''
  and x_offer_versn_desc in ('1C CONNECTIVITY INTRO', 'GSDP INTRO (1D)')
  )


select year(Term_end_date) as yearTED
, month(Term_end_date) as monthTED
, brand
, freetrialflag
, count(distinct u.vin) as vinCount
, count(distinct case when vp.activationtype = 'FULL REGISTRATION' then u.vin end) as enrolledVinCount
from u
left join fca_src_prd.sf_gsdp_ignite_v_vehicleprofile vp on u.vin = vp.vin
where u.cntct_date >= cast('2022-08-25' as date)
and Term_end_date <= cast('2023-07-31' as date)
group by year(Term_end_date)
, month(Term_end_date)
, brand
, freetrialflag
order by year(Term_end_date)
, month(Term_end_date)
, brand
, freetrialflag