/*
Title: Business question OT - Row 5
Author: David Garcia
Description: This query answers the question "What touchpoints contributed to enrollment conversion (O/T attribution)?"
Last updated date: 8/30/2023
Update log
- 8/30/2023: brand is now coming from the camp comm table, deleted the segment type filter, added the brand filter, all the 1D that are sent since 8/25/2023 are flagged as 3+3 free trial
- 8/28/2023: Title and description added into the file, added version 2, version 1 was classified as deprecated
*/
-------------------------------------------------------------------------------------------------Version 2
with u as 
(
  select case when STRPOS(Term_start_date,'-') > 0 then cast(substring(Term_start_date,1,10) as date) else date_parse(substring(Term_start_date,1,10),'%c/%d/%Y') end as term_start_date
  , case when STRPOS(Term_end_date,'-') > 0 then cast(substring(Term_end_date,1,10) as date) else date_parse(substring(Term_end_date,1,10),'%c/%d/%Y') end as term_end_date
  , case when STRPOS(cntct_date,'-') > 0 then cast(substring(cntct_date,1,10) as date) else date_parse(substring(cntct_date,1,10),'%c/%d/%Y') end as cntct_date
  , x_offer_versn_desc
  , c_creatv_versn
  , enroll_status
  , service_type
  , concat(i_vin_first_9, i_vin_last_8) as vin
  , n_cmpgn_seg
  , upper(n_brnd) as Brand
  from service_marketing_reporting.uconnect_gsdp_cntct_hist
  where trim(cntct_date) > ''
  and x_offer_versn_desc in ('1C CONNECTIVITY INTRO'
  , 'GSDP INTRO (1D)') --touchpoint filter
)
select 
year(u.cntct_date) Contact_date_year
, month(u.cntct_date) Contact_date_month --Cadence based on the contact date
, case when n_cmpgn_seg like '%3%' or (u.x_offer_versn_desc = 'GSDP INTRO (1D)' and u.cntct_date >= cast('2022-08-25' as date)) then '3+3 free trial' else '6 month trial' end as free_trial_flag --Free trial flag
, u.brand
-- counts of treated vin
, count(distinct case when u.x_offer_versn_desc in ('1C CONNECTIVITY INTRO') 
    and DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 1 and 7 
    and u.enroll_status = 'notenrolled'
    then u.vin end) as "1C treated"
, count(distinct case when u.x_offer_versn_desc in ('GSDP INTRO (1D)') 
    and DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 1 and 7 
    and u.enroll_status = 'notenrolled'
    then u.vin end) as "1D treated"
, count(distinct case when DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 8 and 11 
    and u.enroll_status = 'notenrolled'
    then u.vin end) as "Alexa treated"
, count(distinct case when DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 12 and 24 
    and u.enroll_status = 'notenrolled'
    then u.vin end) as "Compliments treated"
, count(distinct case when DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 25 and 34 
    and u.enroll_status = 'notenrolled'
    then u.vin end) as "Navigation treated"
, count(distinct case when DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 35 and 44 
    and u.enroll_status = 'notenrolled'
    then u.vin end) as "Sub prompt day 35 treated"
, count(distinct case when DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 45 and 49 
    and u.enroll_status = 'notenrolled'
    then u.vin end) as "Enroll reminder treated"
, count(distinct case when DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 50 and 59 
    then u.vin end) as "Assist treated"
, count(distinct case when DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 60 and 69 
    and u.enroll_status = 'notenrolled'
    then u.vin end) as "Sub Reminder treated"
, count(distinct case when DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 70 and 79 
    and u.enroll_status = 'notenrolled'
    then u.vin end) as "Benefits treated"
, count(distinct case when DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 80 and 90 
    and u.enroll_status = 'notenrolled'
    then u.vin end) as "Last Chance treated"
-- counts and tags based on the difference between the term start date and the activation date to full registration
, count(distinct case when u.x_offer_versn_desc in ('1C CONNECTIVITY INTRO') 
    and DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 1 and 7 
    and vp.activationtype = 'FULL REGISTRATION'
    and u.enroll_status = 'notenrolled'
    then u.vin end) as "1C conversion"
, count(distinct case when u.x_offer_versn_desc in ('GSDP INTRO (1D)') 
    and DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 1 and 7 
    and vp.activationtype = 'FULL REGISTRATION'
    and u.enroll_status = 'notenrolled'
    then u.vin end) as "1D conversion"
, count(distinct case when DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 8 and 11 
    and vp.activationtype = 'FULL REGISTRATION'
    and u.enroll_status = 'notenrolled'
    then u.vin end) as "Alexa conversion"
, count(distinct case when DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 12 and 24 
    and vp.activationtype = 'FULL REGISTRATION'
    and u.enroll_status = 'notenrolled'
    then u.vin end) as "Compliments conversion"
, count(distinct case when DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 25 and 34 
    and vp.activationtype = 'FULL REGISTRATION'
    and u.enroll_status = 'notenrolled'
    then u.vin end) as "Navigation conversion"
, count(distinct case when DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 35 and 44 
    and vp.activationtype = 'FULL REGISTRATION'
    and u.enroll_status = 'notenrolled'
    then u.vin end) as "Sub prompt day 35 conversion"
, count(distinct case when DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 45 and 49 
    and vp.activationtype = 'FULL REGISTRATION'
    and u.enroll_status = 'notenrolled'
    then u.vin end) as "Enroll reminder conversion"
, count(distinct case when DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 50 and 59 
    and vp.activationtype = 'FULL REGISTRATION'
    then u.vin end) as "Assist conversion"
, count(distinct case when DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 60 and 69 
    and vp.activationtype = 'FULL REGISTRATION'
    and u.enroll_status = 'notenrolled'
    then u.vin end) as "Sub Reminder conversion"
, count(distinct case when DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 70 and 79 
    and vp.activationtype = 'FULL REGISTRATION'
    and u.enroll_status = 'notenrolled'
    then u.vin end) as "Benefits conversion"
, count(distinct case when DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 80 and 90 
    and vp.activationtype = 'FULL REGISTRATION'
    and u.enroll_status = 'notenrolled'
    then u.vin end) as "Last Chance conversion"
from u
left join fca_src_prd.sf_gsdp_ignite_v_vehicleprofile vp on u.vin = vp.vin
where u.brand in ('JEEP', 'DODGE', 'RAM', 'WAGONEER')
group by year(u.cntct_date) 
, month(u.cntct_date) 
, case when n_cmpgn_seg like '%3%' or (u.x_offer_versn_desc = 'GSDP INTRO (1D)' and u.cntct_date >= cast('2022-08-25' as date)) then '3+3 free trial' else '6 month trial' end
, u.brand
order by year(u.cntct_date) 
, month(u.cntct_date) 
, case when n_cmpgn_seg like '%3%' or (u.x_offer_versn_desc = 'GSDP INTRO (1D)' and u.cntct_date >= cast('2022-08-25' as date)) then '3+3 free trial' else '6 month trial' end
, u.brand
-------------------------------------------------------------------------------------------------Version 1 (deprecated)
with u as 
(
  select case when STRPOS(Term_start_date,'-') > 0 then cast(substring(Term_start_date,1,10) as date) else date_parse(substring(Term_start_date,1,10),'%c/%d/%Y') end as term_start_date
  , case when STRPOS(Term_end_date,'-') > 0 then cast(substring(Term_end_date,1,10) as date) else date_parse(substring(Term_end_date,1,10),'%c/%d/%Y') end as term_end_date
  , case when STRPOS(cntct_date,'-') > 0 then cast(substring(cntct_date,1,10) as date) else date_parse(substring(cntct_date,1,10),'%c/%d/%Y') end as cntct_date
  , x_offer_versn_desc
  , c_creatv_versn
  , enroll_status
  , service_type
  , concat(i_vin_first_9, i_vin_last_8) as vin
  , n_cmpgn_seg
  from service_marketing_reporting.uconnect_gsdp_cntct_hist
  where trim(cntct_date) > ''
  and x_offer_versn_desc in ('1C CONNECTIVITY INTRO'
  , 'GSDP INTRO (1D)') --touchpoint filter
)
select 
year(u.cntct_date) Contact_date_year
, month(u.cntct_date) Contact_date_month --Cadence based on the contact date
, case when n_cmpgn_seg like '%3%' then '3+3 free trial' else '6 month trial' end as free_trial_flag --Free trial flag
-- counts and tags based on the difference between the term start date and the activation date to full registration
, count(distinct case when u.x_offer_versn_desc in ('1C CONNECTIVITY INTRO') 
    and DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 1 and 7 
    and vp.activationtype = 'FULL REGISTRATION'
    then u.vin end) as "1C conversion"
, count(distinct case when u.x_offer_versn_desc in ('GSDP INTRO (1D)') 
    and DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 1 and 7 
    and vp.activationtype = 'FULL REGISTRATION'
    then u.vin end) as "1D conversion"
, count(distinct case when DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 8 and 11 
    and vp.activationtype = 'FULL REGISTRATION'
    then u.vin end) as "Alexa conversion"
, count(distinct case when DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 12 and 24 
    and vp.activationtype = 'FULL REGISTRATION'
    then u.vin end) as "Compliments conversion"
, count(distinct case when DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 25 and 44 
    and vp.activationtype = 'FULL REGISTRATION'
    then u.vin end) as "Navigation conversion"
, count(distinct case when DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 45 and 49 
    and vp.activationtype = 'FULL REGISTRATION'
    then u.vin end) as "Enroll reminder conversion"
, count(distinct case when DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 50 and 59 
    and vp.activationtype = 'FULL REGISTRATION'
    then u.vin end) as "Assist conversion"
, count(distinct case when DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 60 and 69 
    and vp.activationtype = 'FULL REGISTRATION'
    then u.vin end) as "Sub Reminder conversion"
, count(distinct case when DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 70 and 79 
    and vp.activationtype = 'FULL REGISTRATION'
    then u.vin end) as "Benefits conversion"
, count(distinct case when DATE_DIFF('day', u.term_start_date, cast(substring(vp.activationdate, 1, 10) as date)) between 80 and 90 
    and vp.activationtype = 'FULL REGISTRATION'
    then u.vin end) as "Last Chance conversion"
from u
left join fca_src_prd.sf_gsdp_ignite_v_vehicleprofile vp on u.vin = vp.vin
where u.service_type in ('Basic','Standard') -- Free trial filter
and u.enroll_status = 'notenrolled'
and (n_cmpgn_seg like 'D_%' or n_cmpgn_seg like 'W_%' or n_cmpgn_seg like 'J_%' or n_cmpgn_seg like 'R_%')
group by year(u.cntct_date) 
, month(u.cntct_date) 
, case when n_cmpgn_seg like '%3%' then '3+3 free trial' else '6 month trial' end
order by year(u.cntct_date) 
, month(u.cntct_date) 
, case when n_cmpgn_seg like '%3%' then '3+3 free trial' else '6 month trial' end