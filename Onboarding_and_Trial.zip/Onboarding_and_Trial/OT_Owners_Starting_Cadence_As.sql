/*
Title: Business question OT - Row 3
Author: David Garcia
Description: This query answers the question "How many owners are starting their cadence as enrolled vs. lite enrolled vs. unenrolled vs. services disabled?"
Last updated date: 9/05/2023
Update log
- 9/05/2023: the version 1 is again the oficial version of the BQ, added the new logic of the free trial flag that includes the 1D since 8/25/2023 as 3+3
- 8/30/2023: brand is now coming from the camp comm table, added the brand filter
- 8/28/2023: Added the version 2, the version 1 changed the status to "deprecated"
*/

-------------------------Version 1
with u as 
(
  select case when STRPOS(Term_start_date,'-') > 0 then cast(substring(Term_start_date,1,10) as date) else date_parse(substring(Term_start_date,1,10),'%c/%d/%Y') end as term_start_date
  , case when STRPOS(Term_end_date,'-') > 0 then cast(substring(Term_end_date,1,10) as date) else date_parse(substring(Term_end_date,1,10),'%c/%d/%Y') end as term_end_date
  , case when STRPOS(cntct_date,'-') > 0 then cast(substring(cntct_date,1,10) as date) else date_parse(substring(cntct_date,1,10),'%c/%d/%Y') end as cntct_date
  , x_offer_versn_desc
  , c_creatv_versn
  , enroll_status
  , service_type
  , concat(i_vin_first_9, i_vin_last_8) as vin
  , n_cmpgn_seg
  from service_marketing_reporting.uconnect_gsdp_cntct_hist
  where trim(cntct_date) > ''
)
select 
year(u.cntct_date) Contact_date_year
, month(u.cntct_date) Contact_date_month --Cadence based on the contact date
, case when n_cmpgn_seg like '%3%' or (u.x_offer_versn_desc = 'GSDP INTRO (1D)' and u.cntct_date >= cast('2022-08-25' as date)) then '3+3 free trial' else '6 month trial' end as free_trial_flag --Free trial flag
, count(distinct case when u.x_offer_versn_desc in ('1A/B CONNECTIVITY INTRO','INTRO ADHOC')
  and u.c_creatv_versn in ('CA286','CA287','CA284')
  and u.enroll_status = 'enrolled'
  then u.vin end) as count_enrolled --Count of VIN that started they free trial as enrolled
, count(distinct case when u.x_offer_versn_desc in ('1C CONNECTIVITY INTRO','INTRO ADHOC')
  and u.c_creatv_versn in ('CA285','CA288')
  and u.enroll_status = 'notenrolled'
  then u.vin end) as count_unenrolled --Count of VIN that started they free trial as unenrolled
, count(distinct case when u.x_offer_versn_desc in ('GSDP INTRO (1D)')
  and u.c_creatv_versn in ('CA288')
  and u.enroll_status = 'notenrolled'
  then u.vin end) as count_disabled --Count of VIN that started they free trial as services disabled
from u
left join fca_src_prd.sf_gsdp_ignite_v_vehicleprofile vp on u.vin = vp.vin
group by year(u.cntct_date) 
, month(u.cntct_date) 
, case when n_cmpgn_seg like '%3%' or (u.x_offer_versn_desc = 'GSDP INTRO (1D)' and u.cntct_date >= cast('2022-08-25' as date)) then '3+3 free trial' else '6 month trial' end
order by year(u.cntct_date) 
, month(u.cntct_date) 
, case when n_cmpgn_seg like '%3%' or (u.x_offer_versn_desc = 'GSDP INTRO (1D)' and u.cntct_date >= cast('2022-08-25' as date)) then '3+3 free trial' else '6 month trial' end
