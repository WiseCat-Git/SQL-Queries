/*
Title: Business question OT - Row 6
Author: David Garcia
Description: This query answers the question "What is our CTR performance compared to benchmark? 
 - What dimensions do we need to look at? Touchpoint by touchpoint, by brand, by category?
(Need calrification on what performance is needed; do we need content performane at all?)"
Last updated date: 8/30/2023
Update log
- 8/30/2023: all the 1D that are sent since 8/25/2023 (sfmc send date) are flagged as 3+3 free trial, added the brand filter
- 8/28/2023: Title and description added into the file
*/
with emm as 
(
  select jobid, batchid, subscriberid, listid, domain, 'Sent' as eventcode, eventdate
    , concat(cast(jobid as varchar), cast(batchid as varchar), cast(subscriberid as varchar), cast(listid as varchar)) as sfmcid
    , '' as linkcontent from sfmc_sent
  union all
  select jobid, batchid, subscriberid, listid, domain, 'Open' as eventcode, eventdate 
    , concat(cast(jobid as varchar), cast(batchid as varchar), cast(subscriberid as varchar), cast(listid as varchar)) as sfmcid
    , '' as linkcontent from sfmc_open
  union all
  select jobid, batchid, subscriberid, listid, domain, 'Bounce' as eventcode, eventdate
    , concat(cast(jobid as varchar), cast(batchid as varchar), cast(subscriberid as varchar), cast(listid as varchar)) as sfmcid
    , '' as linkcontent from sfmc_bounce
  union all
  select jobid, batchid, subscriberid, listid, domain, 'Click' as eventcode, eventdate
    , concat(cast(jobid as varchar), cast(batchid as varchar), cast(subscriberid as varchar), cast(listid as varchar)) as sfmcid
    , linkcontent from sfmc_click
  union all
  select jobid, batchid, subscriberid, listid, domain, 'Complaint' as eventcode, eventdate
    , concat(cast(jobid as varchar), cast(batchid as varchar), cast(subscriberid as varchar), cast(listid as varchar)) as sfmcid
    , '' as linkcontent from sfmc_complaint
  union all
  select jobid, batchid, subscriberid, listid, domain, 'Unsubscribe' as eventcode, eventdate
    , concat(cast(jobid as varchar), cast(batchid as varchar), cast(subscriberid as varchar), cast(listid as varchar)) as sfmcid
    , '' as linkcontent from sfmc_unsubscribe
) 
select 
  year(cast(substring(s.eventdate,1,10) as date))
  , month(cast(substring(s.eventdate,1,10) as date)) --Based on the send date
  , upper(u.n_brnd) as brand
  , case when n_cmpgn_seg like '%3%' or (u.x_offer_versn_desc = 'GSDP INTRO (1D)' and cast(substring(s.eventdate,1,10) as date) >= cast('2022-08-25' as date)) then '3+3 free trial' else '6 month trial' end as free_trial_flag --Free trial flag
  , count(distinct case when date_add('day',7,cast(substring(s.eventdate,1,10) as date)) >= cast(substring(emm.eventdate,1,10) as date) and emm.eventcode = 'Sent' then emm.sfmcid end) as "Sent" 
  , count(distinct case when date_add('day',7,cast(substring(s.eventdate,1,10) as date)) >= cast(substring(emm.eventdate,1,10) as date) and emm.eventcode = 'Bounce' then emm.sfmcid end) as "Bounce"
  , count(distinct case when date_add('day',7,cast(substring(s.eventdate,1,10) as date)) >= cast(substring(emm.eventdate,1,10) as date) and emm.eventcode = 'Click' then emm.sfmcid end) as "Unique Clicks"
  , cast(count(distinct case when date_add('day',7,cast(substring(s.eventdate,1,10) as date)) >= cast(substring(emm.eventdate,1,10) as date) and emm.eventcode = 'Click' then emm.sfmcid end) as double) * 100.00 / (cast(count(distinct case when date_add('day',7,cast(substring(s.eventdate,1,10) as date)) >= cast(substring(emm.eventdate,1,10) as date) and emm.eventcode = 'Sent' then emm.sfmcid end) as double) - cast(count(distinct case when date_add('day',7,cast(substring(s.eventdate,1,10) as date)) >= cast(substring(emm.eventdate,1,10) as date) and emm.eventcode = 'Bounce' then emm.sfmcid end) as double)) as CTR --CTR based on the formula that is being used on Qlik
from  sfmc_sendlog sl
inner join sfmc_job j on j.jobid = sl.jobid
inner join sfmc_sent s on sl.jobid = s.jobid 
  and sl.batchid = s.batchid
  and sl.subid = s.subscriberid
  and sl.listid = s.listid
left join emm
  on sl.jobid = emm.jobid
  and sl.batchid = emm.batchid
  and sl.subid = emm.subscriberid
  and sl.listid = emm.listid
inner join service_marketing_reporting.uconnect_gsdp_cntct_hist u on sl.i_campaign = u.i_cmpgn
  and sl.outbound_id = cast(u.i_actvty_otbnd as varchar)
where sl.i_campaign = '8923' and j.emailname not like '%SEASONAL%'
and cast(substring(s.eventdate,1,10) as date) >= cast('2021-08-12' as date) 
and u.n_brnd in ('JEEP', 'DODGE', 'RAM', 'WAGONEER')
group by year(cast(substring(s.eventdate,1,10) as date))
  , month(cast(substring(s.eventdate,1,10) as date))
  , upper(u.n_brnd)
  , case when n_cmpgn_seg like '%3%' or (u.x_offer_versn_desc = 'GSDP INTRO (1D)' and cast(substring(s.eventdate,1,10) as date) >= cast('2022-08-25' as date)) then '3+3 free trial' else '6 month trial' end
order by year(cast(substring(s.eventdate,1,10) as date))
  , month(cast(substring(s.eventdate,1,10) as date))
  , upper(u.n_brnd)
  , case when n_cmpgn_seg like '%3%' or (u.x_offer_versn_desc = 'GSDP INTRO (1D)' and cast(substring(s.eventdate,1,10) as date) >= cast('2022-08-25' as date)) then '3+3 free trial' else '6 month trial' end
