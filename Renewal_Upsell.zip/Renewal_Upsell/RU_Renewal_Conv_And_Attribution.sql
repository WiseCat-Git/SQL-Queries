/*
Title: Renewal attribution
Author: David Garcia
Description: This query answers the following questions
- Of the owners who enter Renewal phase (Those who received any renewal email), what percent subscribe/renew ?.
- What touchpoints contributed to renewal conversion ( Renewal conversion attribution)?
Last updated date: 8/28/2023
Update log
- 8/28/2023: Title and description added into the file.
*/


with u as 
(
  select
  max(cast(substring(cntct_date, 1, 10) as date)) as ContactDate
  , max(cast(substring(Term_end_date, 1, 10) as date)) as termenddate
  , upper(n_brnd) as brand
  , concat(i_vin_first_9, i_vin_last_8) as vin
  , count(case when x_offer_versn_desc = 'Renewal Prompt 30 Day' then 1 end) as subsprompt
  , count(case when x_offer_versn_desc = 'Renewal Prompt 15 Day' then 1 end) as subsreminder
  from service_marketing_reporting.uconnect_gsdp_cntct_hist
  where x_offer_versn_desc in ('Renewal Prompt 15 Day', 'Renewal Prompt 30 Day')
  group by upper(n_brnd) 
  , concat(i_vin_first_9, i_vin_last_8) 
)
select
  year(ContactDate) as yearContactDate
  , month(ContactDate) as monthContactDate
  , brand
  , sus.productcode
  , try_cast(currentterm as int) as currentterm
  , Currenttermperiodtype
  , sus.Autorenew
  , count(distinct 
    case when sus.Servicetype = 'Optional' 
    and u.ContactDate <= cast(substring(sus.termstartdate, 1, 10) as date) 
    then u.vin 
    end) as convertedVinCount
  , count(distinct 
    case when sus.Servicetype = 'Optional' 
    and u.ContactDate <= cast(substring(sus.termstartdate, 1, 10) as date) 
    and u.termenddate < cast(substring(sus.termenddate, 1, 10) as date)
    and subsprompt = 1 and subsreminder = 0
    then u.vin 
    end) as SubsPromptAttribution
  , count(distinct 
    case when sus.Servicetype = 'Optional' 
    and u.ContactDate <= cast(substring(sus.termstartdate, 1, 10) as date) 
    and u.termenddate < cast(substring(sus.termenddate, 1, 10) as date)
    and subsreminder = 1
    then u.vin 
    end) as SubsReminderAttribution
from u
inner join fca_src_prd.sf_gsdp_ignite_v_subscription sus on u.vin = sus.vin
where (productcode like '%Assistance%' or productcode like '%Navigation%')
and sus.Servicetype = 'Optional' 
group by year(ContactDate) 
  , month(ContactDate) 
  , brand
  , sus.productcode
  , try_cast(currentterm as int)
  , Currenttermperiodtype
  , sus.Autorenew
order by year(ContactDate) 
  , month(ContactDate) 
  , brand
  , sus.productcode
  , try_cast(currentterm as int)
  , Currenttermperiodtype
  , sus.Autorenew
