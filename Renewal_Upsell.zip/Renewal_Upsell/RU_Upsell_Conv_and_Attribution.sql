/*
Title: upsell attribution
Author: David Garcia
Description: This query returns the data of the upsell attribution
Last updated date: 8/28/2023
Update log
- 8/28/2023: Title and description added into the file. 
*/


select
  year(cast(substring(u.cntct_date, 1, 10) as date)) as yearContactDate
  , month(cast(substring(cntct_date, 1, 10) as date)) as monthContactDate
  , upper(n_brnd) as brand
  , sus.productcode
  , try_cast(currentterm as int) as currentterm
  , Currenttermperiodtype
  , sus.Autorenew
  , count(distinct case when sus.Servicetype = 'Optional'
    and cast(substring(u.cntct_date, 1, 10) as date) <= cast(substring(sus.termstartdate, 1, 10) as date) 
    then concat(u.i_vin_first_9, u.i_vin_last_8) end) as convertedVinCount
  , count(distinct case when sus.Servicetype = 'Optional'
    and date_diff('day', cast(substring(u.cntct_date, 1, 10) as date), cast(substring(sus.termstartdate, 1, 10) as date)) between 0 and 30
    then concat(u.i_vin_first_9, u.i_vin_last_8) end) as attributedVinCount
from service_marketing_reporting.uconnect_gsdp_cntct_hist u
inner join fca_src_prd.sf_gsdp_ignite_v_subscription sus on concat(u.i_vin_first_9, u.i_vin_last_8) = sus.vin
where u.x_offer_versn_desc in ('Subscription Upsell')
and (productcode like '%Assistance%' or productcode like '%Navigation%')
and sus.Servicetype = 'Optional' 
group by year(cast(substring(u.cntct_date, 1, 10) as date)) 
  , month(cast(substring(cntct_date, 1, 10) as date)) 
  , upper(n_brnd)
  , sus.productcode
  , try_cast(currentterm as int)
  , Currenttermperiodtype
  , sus.Autorenew
order by year(cast(substring(u.cntct_date, 1, 10) as date)) 
  , month(cast(substring(cntct_date, 1, 10) as date)) 
  , upper(n_brnd)
  , sus.productcode
  , try_cast(currentterm as int)
  , Currenttermperiodtype
  , sus.Autorenew