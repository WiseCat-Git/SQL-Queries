/*
Title: Business question OT - Row 3
Author: David Garcia
Description: This query answers the question "How many owners are starting their cadence as enrolled vs. lite enrolled vs. unenrolled vs. services disabled?"
Last updated date: 10/18/2023
Update log
- 11/7/2023: demo file created and added the state column
- 10/18/2023: brand column added
- 9/05/2023: the version 1 is again the oficial version of the BQ, added the new logic of the free trial flag that includes the 1D since 8/25/2023 as 3+3
- 8/30/2023: brand is now coming from the camp comm table, added the brand filter
- 8/28/2023: Added the version 2, the version 1 changed the status to "deprecated"
*/

-------------------------Version 1
with u as 
(
  select case when STRPOS(Term_start_date,'-') > 0 then cast(substring(Term_start_date,1,10) as date) else date_parse(substring(Term_start_date,1,10),'%c/%d/%Y') end as term_start_date
  , case when STRPOS(Term_end_date,'-') > 0 then cast(substring(Term_end_date,1,10) as date) else date_parse(substring(Term_end_date,1,10),'%c/%d/%Y') end as term_end_date
  , case when STRPOS(cntct_date,'-') > 0 then cast(substring(cntct_date,1,10) as date) else date_parse(substring(cntct_date,1,10),'%c/%d/%Y') end as cntct_date
  , x_offer_versn_desc
  , c_creatv_versn
  , enroll_status
  , service_type
  , concat(i_vin_first_9, i_vin_last_8) as vin
  , n_cmpgn_seg
  , case when upper(n_brnd) = 'R' then 'RAM' when upper(n_brnd) = 'W' then 'WAGONEER' when upper(n_brnd) = 'J' then 'JEEP' else upper(n_brnd) end as n_brnd
  from service_marketing_reporting.uconnect_gsdp_cntct_hist
  where trim(cntct_date) > ''
)
, demodata as
(
  select 
    u.i_consmr
    , concat(u.i_vin_first_9, u.i_vin_last_8) as vin
    , c_persn_sex_1
    , demosex.x_colm_val_desc as N_PERSN_SEX_1
    , c_adlt_age
    , c_martl_stat
    , demomaritan.x_colm_val_desc as N_MARTL_STAT
    , demoedlev.x_colm_val_desc as N_EDUC
    , demoocc.x_colm_val_desc as N_OCCPTN
    , demohhi.x_colm_val_desc as N_HSHLD_INC_BAND
	, demohhcat.x_colm_val_desc as C_HSHLD_CATGY_TYP
	, demo.i_zip_5
    , z.c_state
  from service_marketing_reporting.uconnect_gsdp_cntct_hist u
  inner join fca_stg_prd.cms_cons_demo_info demo on u.i_consmr = demo.i_consmr
  left join fca_src_prd.cms_cms_mstr_cd_demo demosex on trim(demosex.x_colm_val) = trim(demo.c_persn_sex_1) and trim(demosex.N_COLM) = 'C_PERSN_SEX_1'
  left join fca_src_prd.cms_cms_mstr_cd_demo demomaritan on trim(demomaritan.x_colm_val) = trim(demo.c_martl_stat) and trim(demomaritan.N_COLM) = 'C_MARTL_STAT'
  left join fca_src_prd.cms_cms_mstr_cd_demo demoedlev on trim(demoedlev.x_colm_val) = trim(demo.C_EDUC) and trim(demoedlev.N_COLM) = 'C_EDUC'
  left join fca_src_prd.cms_cms_mstr_cd_demo demoocc on trim(demoocc.x_colm_val) = trim(demo.C_OCCPTN) and trim(demoocc.N_COLM) = 'C_OCCPTN'
  left join fca_src_prd.cms_cms_mstr_cd_demo demohhi on trim(demohhi.x_colm_val) = trim(demo.A_HSHLD_INC_BAND) and trim(demohhi.N_COLM) = 'A_HSHLD_INC_BAND'
  left join fca_src_prd.cms_cms_mstr_cd_demo demohhcat on trim(demohhcat.x_colm_val) = trim(demo.C_HSHLD_CATGY_TYP) and trim(demohhcat.N_COLM) = 'C_HSHLD_CATGY_TYP'
  left join fca_stg_prd.cms_cms_zip_state z on demo.i_zip_5 = z.i_zip_5
)
select 
year(u.cntct_date) Contact_date_year
, month(u.cntct_date) Contact_date_month --Cadence based on the contact date
, case when n_cmpgn_seg like '%3%' or (u.x_offer_versn_desc = 'GSDP INTRO (1D)' and u.cntct_date >= cast('2022-08-25' as date)) then '3+3 free trial' else '6 month trial' end as free_trial_flag --Free trial flag
, u.n_brnd
, demodata.N_PERSN_SEX_1
, demodata.c_adlt_age
, demodata.N_MARTL_STAT
, demodata.N_EDUC
, demodata.c_state
, count(distinct case when u.x_offer_versn_desc in ('1A/B CONNECTIVITY INTRO','INTRO ADHOC')
  and u.c_creatv_versn in ('CA286','CA287','CA284')
  and u.enroll_status = 'enrolled'
  then u.vin end) as count_enrolled --Count of VIN that started they free trial as enrolled
, count(distinct case when u.x_offer_versn_desc in ('1C CONNECTIVITY INTRO','INTRO ADHOC')
  and u.c_creatv_versn in ('CA285','CA288')
  and u.enroll_status = 'notenrolled'
  then u.vin end) as count_unenrolled --Count of VIN that started they free trial as unenrolled
, count(distinct case when u.x_offer_versn_desc in ('GSDP INTRO (1D)')
  and u.c_creatv_versn in ('CA288')
  and u.enroll_status = 'notenrolled'
  then u.vin end) as count_disabled --Count of VIN that started they free trial as services disabled
from u
left join fca_src_prd.sf_gsdp_ignite_v_vehicleprofile vp on u.vin = vp.vin
left join demodata on u.vin = demodata.vin
group by year(u.cntct_date) 
, month(u.cntct_date) 
, case when n_cmpgn_seg like '%3%' or (u.x_offer_versn_desc = 'GSDP INTRO (1D)' and u.cntct_date >= cast('2022-08-25' as date)) then '3+3 free trial' else '6 month trial' end
, u.n_brnd
, demodata.N_PERSN_SEX_1
, demodata.c_adlt_age
, demodata.N_MARTL_STAT
, demodata.N_EDUC
, demodata.c_state
order by year(u.cntct_date) 
, month(u.cntct_date) 
, case when n_cmpgn_seg like '%3%' or (u.x_offer_versn_desc = 'GSDP INTRO (1D)' and u.cntct_date >= cast('2022-08-25' as date)) then '3+3 free trial' else '6 month trial' end
