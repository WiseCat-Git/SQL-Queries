
/*
Title: Packages subscription by package type
Author: David Garcia
Description: This query answers the questions "What packages are owners subscribing to? assistance only vs. navigation only vs. assist+nav joint", optional to include the demo data
Last updated date: 10/23/2023
Update log
- 11/07/2023: added the state
- 10/23/2023: exclusive file created that includes the demo data
- 10/18/2023: checked query logic
- 10/11/2023: changed brand logic, added year and free trial flag 
- 9/04/2023: Added the package NA_Assist+Navigation_Opt, added a comment to check the date range before running
- 8/28/2023: Title and description added into the file.
*/

with sourceCTE as (
select distinct 
  year(cast(substring(sus.termstartdate, 1, 10) as date)) as Yeartermstartdate
  , month(cast(substring(sus.termstartdate, 1, 10) as date)) as Monthtermstartdate
  , upper(case when n_brnd = 'J' then 'JEEP' when n_brnd = 'R' then 'RAM' when n_brnd = 'W' then 'WAGONEER' else COALESCE(N_brnd, Vinmake) end) as brand
  , case when n_cmpgn_seg like '%3%' or (u.x_offer_versn_desc = 'GSDP INTRO (1D)' and cast(substring(u.cntct_date, 1, 10) as date) >= cast('2022-08-25' as date)) then '3+3 free trial' else '6 month trial' end as free_trial_flag
  , case when sus.productcode = 'NA_Assistance_Opt' or sus.productcode = 'NA_Assist+Navigation_Opt' then 'X' end as HasAssistance
  , case when sus.productcode = 'NA_Navigation_Opt' or sus.productcode = 'NA_Assist+Navigation_Opt' then 'X' end as HasNavigation
  , sus.vin
from fca_src_prd.sf_gsdp_ignite_v_subscription sus
inner join fca_src_prd.sf_gsdp_ignite_v_vehicleprofile vp on sus.vin = vp.vin
left join service_marketing_reporting.uconnect_gsdp_cntct_hist u on sus.vin = concat(i_vin_first_9, i_vin_last_8) 
where cast(substring(sus.termstartdate, 1, 10) as date) between cast ('2023-01-01' as date) and cast ('2023-09-30' as date) --check the right date range before running
and sus.productcode in ('NA_Assistance_Opt', 'NA_Navigation_Opt', 'NA_Assist+Navigation_Opt')
)
, groupCTE as (
select 
  vin
  , Yeartermstartdate
  , Monthtermstartdate
  , brand
  , free_trial_flag
  , count(case when HasAssistance = 'X' and HasNavigation is null then 1 end) as Assistance
  , count(case when HasNavigation = 'X' and HasAssistance is null then 1 end) as Navigation
from sourceCTE
  group by vin
  , Yeartermstartdate
  , Monthtermstartdate
  , brand
  , free_trial_flag)
, demodata as
	(
	  select 
		u.i_consmr
		, concat(u.i_vin_first_9, u.i_vin_last_8) as vin
		, c_persn_sex_1
		, demosex.x_colm_val_desc as N_PERSN_SEX_1
		, c_adlt_age
		, c_martl_stat
		, demomaritan.x_colm_val_desc as N_MARTL_STAT
		, demoedlev.x_colm_val_desc as N_EDUC
		, demoocc.x_colm_val_desc as N_OCCPTN
		, demohhi.x_colm_val_desc as N_HSHLD_INC_BAND
		, demohhcat.x_colm_val_desc as C_HSHLD_CATGY_TYP
		, demo.i_zip_5
		, z.c_state
	  from service_marketing_reporting.uconnect_gsdp_cntct_hist u
	  inner join fca_stg_prd.cms_cons_demo_info demo on u.i_consmr = demo.i_consmr
	  left join fca_src_prd.cms_cms_mstr_cd_demo demosex on trim(demosex.x_colm_val) = trim(demo.c_persn_sex_1) and trim(demosex.N_COLM) = 'C_PERSN_SEX_1'
	  left join fca_src_prd.cms_cms_mstr_cd_demo demomaritan on trim(demomaritan.x_colm_val) = trim(demo.c_martl_stat) and trim(demomaritan.N_COLM) = 'C_MARTL_STAT'
	  left join fca_src_prd.cms_cms_mstr_cd_demo demoedlev on trim(demoedlev.x_colm_val) = trim(demo.C_EDUC) and trim(demoedlev.N_COLM) = 'C_EDUC'
	  left join fca_src_prd.cms_cms_mstr_cd_demo demoocc on trim(demoocc.x_colm_val) = trim(demo.C_OCCPTN) and trim(demoocc.N_COLM) = 'C_OCCPTN'
	  left join fca_src_prd.cms_cms_mstr_cd_demo demohhi on trim(demohhi.x_colm_val) = trim(demo.A_HSHLD_INC_BAND) and trim(demohhi.N_COLM) = 'A_HSHLD_INC_BAND'
	  left join fca_src_prd.cms_cms_mstr_cd_demo demohhcat on trim(demohhcat.x_colm_val) = trim(demo.C_HSHLD_CATGY_TYP) and trim(demohhcat.N_COLM) = 'C_HSHLD_CATGY_TYP'
	  left join fca_stg_prd.cms_cms_zip_state z on demo.i_zip_5 = z.i_zip_5
	)
select 
  Yeartermstartdate
  , Monthtermstartdate
  , brand
  , demodata.N_PERSN_SEX_1
	, demodata.c_adlt_age
	, demodata.N_MARTL_STAT
	, demodata.N_EDUC
	, demodata.c_state
  -- , free_trial_flag
  , count(distinct case when Assistance = 1 and Navigation = 0 then groupCTE.vin end) OnlyAssistance
  , count(distinct case when Assistance = 0 and Navigation = 1 then groupCTE.vin end) OnlyNavigation
  , count(distinct case when Assistance = 1 and Navigation = 1 then groupCTE.vin end) AssistancePlusNavigation 
from groupCTE
left join demodata on groupCTE.vin = demodata.vin
group by Yeartermstartdate, Monthtermstartdate
  -- , free_trial_flag
  , brand
  , demodata.N_PERSN_SEX_1
  	, demodata.c_adlt_age
	, demodata.N_MARTL_STAT
	, demodata.N_EDUC
	, demodata.N_OCCPTN
	, demodata.N_HSHLD_INC_BAND
	, demodata.C_HSHLD_CATGY_TYP
	, demodata.c_state
order by Yeartermstartdate, Monthtermstartdate
  -- , free_trial_flag
  , brand
