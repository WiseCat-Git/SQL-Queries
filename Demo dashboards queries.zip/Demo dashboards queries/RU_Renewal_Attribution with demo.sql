/*
Title: Renewal attribution
Author: David Garcia
Description: This query answers the following questions
- Of the owners who enter Renewal phase (Those who received any renewal email), what percent subscribe/renew ?.
- What touchpoints contributed to renewal conversion ( Renewal conversion attribution)?
Last updated date: 8/28/2023
Update log
- 11/07/2023: added the demo data with state
- 8/28/2023: Title and description added into the file.
*/


with u as 
(
  select
  max(cast(substring(cntct_date, 1, 10) as date)) as ContactDate
  , max(cast(substring(Term_end_date, 1, 10) as date)) as termenddate
  , upper(n_brnd) as brand
  , concat(i_vin_first_9, i_vin_last_8) as vin
  , count(case when x_offer_versn_desc = 'Renewal Prompt 30 Day' then 1 end) as renewprompt
  , count(case when x_offer_versn_desc = 'Renewal Prompt 15 Day' then 1 end) as renewreminder
  from service_marketing_reporting.uconnect_gsdp_cntct_hist
  where x_offer_versn_desc in ('Renewal Prompt 15 Day', 'Renewal Prompt 30 Day')
  group by upper(n_brnd) 
  , concat(i_vin_first_9, i_vin_last_8) 
), demodata as
(
  select 
    u.i_consmr
    , concat(u.i_vin_first_9, u.i_vin_last_8) as vin
    , c_persn_sex_1
    , demosex.x_colm_val_desc as N_PERSN_SEX_1
    , c_adlt_age
    , c_martl_stat
    , demomaritan.x_colm_val_desc as N_MARTL_STAT
    , demoedlev.x_colm_val_desc as N_EDUC
    , demoocc.x_colm_val_desc as N_OCCPTN
    , demohhi.x_colm_val_desc as N_HSHLD_INC_BAND
	, demohhcat.x_colm_val_desc as C_HSHLD_CATGY_TYP
	, demo.i_zip_5
    , z.c_state
  from service_marketing_reporting.uconnect_gsdp_cntct_hist u
  inner join fca_stg_prd.cms_cons_demo_info demo on u.i_consmr = demo.i_consmr
  left join fca_src_prd.cms_cms_mstr_cd_demo demosex on trim(demosex.x_colm_val) = trim(demo.c_persn_sex_1) and trim(demosex.N_COLM) = 'C_PERSN_SEX_1'
  left join fca_src_prd.cms_cms_mstr_cd_demo demomaritan on trim(demomaritan.x_colm_val) = trim(demo.c_martl_stat) and trim(demomaritan.N_COLM) = 'C_MARTL_STAT'
  left join fca_src_prd.cms_cms_mstr_cd_demo demoedlev on trim(demoedlev.x_colm_val) = trim(demo.C_EDUC) and trim(demoedlev.N_COLM) = 'C_EDUC'
  left join fca_src_prd.cms_cms_mstr_cd_demo demoocc on trim(demoocc.x_colm_val) = trim(demo.C_OCCPTN) and trim(demoocc.N_COLM) = 'C_OCCPTN'
  left join fca_src_prd.cms_cms_mstr_cd_demo demohhi on trim(demohhi.x_colm_val) = trim(demo.A_HSHLD_INC_BAND) and trim(demohhi.N_COLM) = 'A_HSHLD_INC_BAND'
  left join fca_src_prd.cms_cms_mstr_cd_demo demohhcat on trim(demohhcat.x_colm_val) = trim(demo.C_HSHLD_CATGY_TYP) and trim(demohhcat.N_COLM) = 'C_HSHLD_CATGY_TYP'
  left join fca_stg_prd.cms_cms_zip_state z on demo.i_zip_5 = z.i_zip_5
)
select
  year(ContactDate) as yearContactDate
  , month(ContactDate) as monthContactDate
  , brand
  , sus.productcode
  , try_cast(currentterm as int) as currentterm
  , Currenttermperiodtype
  , sus.Autorenew
    , demodata.N_PERSN_SEX_1
	, demodata.c_adlt_age
	, demodata.N_MARTL_STAT
	, demodata.N_EDUC
	, demodata.c_state
  , count(distinct 
    case when sus.Servicetype = 'Optional' 
    and u.ContactDate <= cast(substring(sus.termenddate, 1, 10) as date) 
    then u.vin 
    end) as convertedVinCount
  , count(distinct 
    case when sus.Servicetype = 'Optional' 
    and u.ContactDate <= cast(substring(sus.termenddate, 1, 10) as date) 
    and u.termenddate < cast(substring(sus.termenddate, 1, 10) as date)
    and renewprompt = 1 and renewreminder = 0
    then u.vin 
    end) as RenewalPromptAttribution
  , count(distinct 
    case when sus.Servicetype = 'Optional' 
    and u.ContactDate <= cast(substring(sus.termenddate, 1, 10) as date)  
    and u.termenddate < cast(substring(sus.termenddate, 1, 10) as date)
    and renewreminder = 1
    then u.vin 
    end) as RenewalReminderAttribution
from u
inner join fca_src_prd.sf_gsdp_ignite_v_subscription sus on u.vin = sus.vin
left join demodata on sus.vin = demodata.vin
where (productcode like '%Assistance%' or productcode like '%Navigation%')
and sus.Servicetype = 'Optional' 
group by year(ContactDate) 
  , month(ContactDate) 
  , brand
  , sus.productcode
  , try_cast(currentterm as int)
  , Currenttermperiodtype
  , sus.Autorenew
  , demodata.N_PERSN_SEX_1
	, demodata.c_adlt_age
	, demodata.N_MARTL_STAT
	, demodata.N_EDUC
	, demodata.c_state
order by year(ContactDate) 
  , month(ContactDate) 
  , brand
  , sus.productcode
  , try_cast(currentterm as int)
  , Currenttermperiodtype
  , sus.Autorenew
