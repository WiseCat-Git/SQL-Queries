/*
Title: Enrollment conversion at the end of 90 days
Author: David Garcia
Description: This query answers the question "What is our enrollment conversion at the end of the 90 days ?"

- 1C CONNECTIVITY INTRO is for the unenrolled VALUES
- GSDP INTRO (1D) is fro the disabled VALUES
Last updated date: 10/23/2023
Update log
- 10/23/2023: exclusive file created that includes the demo data
- 10/17/2023: added filter that includes both 1C and 1D, added the free trial flag column
- 10/2/2023: added the 1D line filter
- 9/14/2023: added the column enrolled vin count
- 9/06/2023: new query created
*/

with u as (
select case when STRPOS(Term_end_date,'-') > 0 then cast(substring(Term_end_date,1,10) as date) else date_parse(substring(Term_end_date,1,10),'%c/%d/%Y') end as term_end_date
  , service_type
  , concat(i_vin_first_9, i_vin_last_8) as vin
  , upper(n_brnd) as Brand
  , cast(substring(cntct_date,1,10) as date) as cntct_date
  , x_offer_versn_desc
  , n_cmpgn_seg
  from service_marketing_reporting.uconnect_gsdp_cntct_hist
  where trim(Term_end_date) > ''
  ---------------------------------------------Check what filter is required to comment/uncomment the correspondent line-------------------------
  --and x_offer_versn_desc = '1C CONNECTIVITY INTRO' and n_cmpgn_seg like '%3%' -- 1C filter 
  --and x_offer_versn_desc = 'GSDP INTRO (1D)' and cast(substring(cntct_date,1,10) as date) >= cast('2022-08-25' as date) -- 1D filter
  and ((x_offer_versn_desc = '1C CONNECTIVITY INTRO' and n_cmpgn_seg like '%3%') or (x_offer_versn_desc = 'GSDP INTRO (1D)' and cast(substring(cntct_date,1,10) as date) >= cast('2022-08-25' as date))) -- both filters
  -----------------------------------------------------------------------------------------------------------------------------------------------
  )
, demodata as
(
  select 
    u.i_consmr
    , concat(u.i_vin_first_9, u.i_vin_last_8) as vin
    , c_persn_sex_1
    , demosex.x_colm_val_desc as N_PERSN_SEX_1
    , c_adlt_age
    , c_martl_stat
    , demomaritan.x_colm_val_desc as N_MARTL_STAT
    , demoedlev.x_colm_val_desc as N_EDUC
    , demoocc.x_colm_val_desc as N_OCCPTN
    , demohhi.x_colm_val_desc as N_HSHLD_INC_BAND
	, demohhcat.x_colm_val_desc as C_HSHLD_CATGY_TYP
  from service_marketing_reporting.uconnect_gsdp_cntct_hist u
  inner join fca_stg_prd.cms_cons_demo_info demo on u.i_consmr = demo.i_consmr
  left join fca_src_prd.cms_cms_mstr_cd_demo demosex on trim(demosex.x_colm_val) = trim(demo.c_persn_sex_1) and trim(demosex.N_COLM) = 'C_PERSN_SEX_1'
  left join fca_src_prd.cms_cms_mstr_cd_demo demomaritan on trim(demomaritan.x_colm_val) = trim(demo.c_martl_stat) and trim(demomaritan.N_COLM) = 'C_MARTL_STAT'
  left join fca_src_prd.cms_cms_mstr_cd_demo demoedlev on trim(demoedlev.x_colm_val) = trim(demo.C_EDUC) and trim(demoedlev.N_COLM) = 'C_EDUC'
  left join fca_src_prd.cms_cms_mstr_cd_demo demoocc on trim(demoocc.x_colm_val) = trim(demo.C_OCCPTN) and trim(demoocc.N_COLM) = 'C_OCCPTN'
  left join fca_src_prd.cms_cms_mstr_cd_demo demohhi on trim(demohhi.x_colm_val) = trim(demo.A_HSHLD_INC_BAND) and trim(demohhi.N_COLM) = 'A_HSHLD_INC_BAND'
  left join fca_src_prd.cms_cms_mstr_cd_demo demohhcat on trim(demohhcat.x_colm_val) = trim(demo.C_HSHLD_CATGY_TYP) and trim(demohhcat.N_COLM) = 'C_HSHLD_CATGY_TYP'
)
select year(Term_end_date) as yearTED
, month(Term_end_date) as monthTED
, vp.activationtype
, u.brand
, service_type
, case when x_offer_versn_desc = '1C CONNECTIVITY INTRO' and n_cmpgn_seg like '%3%' then 'unenrolled'
    when x_offer_versn_desc = 'GSDP INTRO (1D)' and cntct_date >= cast('2022-08-25' as date) then 'disabled' 
    end as free_trial_flag
, demodata.N_PERSN_SEX_1
, demodata.c_adlt_age
, demodata.N_MARTL_STAT
, demodata.N_EDUC
, demodata.N_OCCPTN
, demodata.N_HSHLD_INC_BAND
, demodata.C_HSHLD_CATGY_TYP
, count(distinct u.vin) as vinCount
, count(distinct case when vp.activationtype = 'FULL REGISTRATION' then u.vin end) as enrolledVinCount
from u
left join fca_src_prd.sf_gsdp_ignite_v_vehicleprofile vp on u.vin = vp.vin
left join demodata on u.vin = demodata.vin
where u.brand in ('JEEP', 'DODGE', 'RAM', 'WAGONEER')
group by year(Term_end_date)
, month(Term_end_date)
, vp.activationtype
, service_type
, case when x_offer_versn_desc = '1C CONNECTIVITY INTRO' and n_cmpgn_seg like '%3%' then 'unenrolled'
    when x_offer_versn_desc = 'GSDP INTRO (1D)' and cntct_date >= cast('2022-08-25' as date) then 'disabled' 
    end
, u.brand
, demodata.N_PERSN_SEX_1
, demodata.c_adlt_age
, demodata.N_MARTL_STAT
, demodata.N_EDUC
, demodata.N_OCCPTN
, demodata.N_HSHLD_INC_BAND
, demodata.C_HSHLD_CATGY_TYP
order by year(Term_end_date)
, month(Term_end_date)
, vp.activationtype
, service_type
, free_trial_flag
, u.brand