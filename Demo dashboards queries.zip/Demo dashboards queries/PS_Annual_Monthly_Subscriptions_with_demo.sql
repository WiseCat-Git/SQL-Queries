
/*
Title: Packages subscription by period type
Author: David Garcia
Description: This query answers the question "What percentage of owners are subscribing to annual vs. monthly subscriptions?", optional to include the demo data
Last updated date: 10/23/2023
Update log
- 11/07/2023: added the state
- 10/23/2023: exclusive file created that includes the demo data
- 10/11/2023: added year and free trial flag
- 10/09/2023: Changed the logic of brand, added the comment to check the dates
- 9/06/2023: added the product code NA_Assist+Navigation_Opt
- 8/28/2023: Title and description added into the file.
*/
with demodata as
(
  select 
    u.i_consmr
    , concat(u.i_vin_first_9, u.i_vin_last_8) as vin
    , c_persn_sex_1
    , demosex.x_colm_val_desc as N_PERSN_SEX_1
    , c_adlt_age
    , c_martl_stat
    , demomaritan.x_colm_val_desc as N_MARTL_STAT
    , demoedlev.x_colm_val_desc as N_EDUC
    , demoocc.x_colm_val_desc as N_OCCPTN
    , demohhi.x_colm_val_desc as N_HSHLD_INC_BAND
	, demohhcat.x_colm_val_desc as C_HSHLD_CATGY_TYP
	, demo.i_zip_5
    , z.c_state
  from service_marketing_reporting.uconnect_gsdp_cntct_hist u
  inner join fca_stg_prd.cms_cons_demo_info demo on u.i_consmr = demo.i_consmr
  left join fca_src_prd.cms_cms_mstr_cd_demo demosex on trim(demosex.x_colm_val) = trim(demo.c_persn_sex_1) and trim(demosex.N_COLM) = 'C_PERSN_SEX_1'
  left join fca_src_prd.cms_cms_mstr_cd_demo demomaritan on trim(demomaritan.x_colm_val) = trim(demo.c_martl_stat) and trim(demomaritan.N_COLM) = 'C_MARTL_STAT'
  left join fca_src_prd.cms_cms_mstr_cd_demo demoedlev on trim(demoedlev.x_colm_val) = trim(demo.C_EDUC) and trim(demoedlev.N_COLM) = 'C_EDUC'
  left join fca_src_prd.cms_cms_mstr_cd_demo demoocc on trim(demoocc.x_colm_val) = trim(demo.C_OCCPTN) and trim(demoocc.N_COLM) = 'C_OCCPTN'
  left join fca_src_prd.cms_cms_mstr_cd_demo demohhi on trim(demohhi.x_colm_val) = trim(demo.A_HSHLD_INC_BAND) and trim(demohhi.N_COLM) = 'A_HSHLD_INC_BAND'
  left join fca_src_prd.cms_cms_mstr_cd_demo demohhcat on trim(demohhcat.x_colm_val) = trim(demo.C_HSHLD_CATGY_TYP) and trim(demohhcat.N_COLM) = 'C_HSHLD_CATGY_TYP'
  left join fca_stg_prd.cms_cms_zip_state z on demo.i_zip_5 = z.i_zip_5
)
select
  year(cast(substring(sus.termstartdate, 1, 10) as date)) as Yeartermstartdate
  , month(cast(substring(sus.termstartdate, 1, 10) as date)) as Monthtermstartdate
  , upper(case when upper(vinmodel2) = 'WAGONEER' THEN vinmodel2 when n_brnd = 'J' then 'JEEP' when n_brnd = 'R' then 'RAM' when n_brnd = 'W' then 'WAGONEER' else COALESCE(N_brnd, Vinmake) end) as brand 
  , Currenttermperiodtype
  , Currentterm
  , case when n_cmpgn_seg like '%3%' or (u.x_offer_versn_desc = 'GSDP INTRO (1D)' and cast(substring(u.cntct_date, 1, 10) as date) >= cast('2022-08-25' as date)) then '3+3 free trial' else '6 month trial' end as free_trial_flag
  , demodata.N_PERSN_SEX_1
, demodata.c_adlt_age
, demodata.N_MARTL_STAT
, demodata.N_EDUC
, demodata.c_state
  , count(distinct sus.vin) as vincount
from fca_src_prd.sf_gsdp_ignite_v_subscription sus
inner join fca_src_prd.sf_gsdp_ignite_v_vehicleprofile vp on sus.vin = vp.vin
left join service_marketing_reporting.uconnect_gsdp_cntct_hist u on concat(i_vin_first_9, i_vin_last_8) = vp.vin
left join demodata on sus.vin = demodata.vin
where cast(substring(sus.termstartdate, 1, 10) as date) between cast ('2023-01-01' as date) and cast ('2023-10-31' as date) --------------------------check the dates-------
and sus.productcode in ('NA_Assistance_Opt', 'NA_Navigation_Opt', 'NA_Assist+Navigation_Opt')
group by year(cast(substring(sus.termstartdate, 1, 10) as date)) 
  , month(cast(substring(sus.termstartdate, 1, 10) as date))
  , upper(case when upper(vinmodel2) = 'WAGONEER' THEN vinmodel2 when n_brnd = 'J' then 'JEEP' when n_brnd = 'R' then 'RAM' when n_brnd = 'W' then 'WAGONEER' else COALESCE(N_brnd, Vinmake) end)
  , Currenttermperiodtype
  , Currentterm
  , case when n_cmpgn_seg like '%3%' or (u.x_offer_versn_desc = 'GSDP INTRO (1D)' and cast(substring(u.cntct_date, 1, 10) as date) >= cast('2022-08-25' as date)) then '3+3 free trial' else '6 month trial' end 
  , demodata.N_PERSN_SEX_1
, demodata.c_adlt_age
, demodata.N_MARTL_STAT
, demodata.N_EDUC
, demodata.c_state
order by month(cast(substring(sus.termstartdate, 1, 10) as date))
  , upper(case when upper(vinmodel2) = 'WAGONEER' THEN vinmodel2 when n_brnd = 'J' then 'JEEP' when n_brnd = 'R' then 'RAM' when n_brnd = 'W' then 'WAGONEER' else COALESCE(N_brnd, Vinmake) end)
  , Currenttermperiodtype
  , Currentterm
