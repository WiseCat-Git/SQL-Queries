/*
Title: Winback conversion
Author: David Garcia
Description: This query answers the question "Of the owners who enter Lapse Prompt Winback phase, what percent subscribe?"
Last updated date: 10/23/2023
Update log
- 10/23/2023: exclusive file created that includes the demo data
- 10/10/2023: labels updated
- 8/28/2023: Title and description added into the file. 
*/

WITH u AS-- camp comm
(
  SELECT CASE WHEN STRPOS(Term_start_date,'-')> 0 THEN CAST(SUBSTRING(Term_start_date,1,10) AS DATE)
      ELSE date_parse(SUBSTRING(Term_start_date,1,10),'%c/%d/%Y')END AS term_start_date,
    CASE WHEN STRPOS(Term_end_date,'-')> 0 THEN CAST(SUBSTRING(Term_end_date,1,10) AS DATE)
      ELSE date_parse(SUBSTRING(Term_end_date,1,10),'%c/%d/%Y')END AS term_end_date,
    CASE WHEN STRPOS(cntct_date,'-')> 0 THEN CAST(SUBSTRING(cntct_date,1,10) AS DATE)
      ELSE date_parse(SUBSTRING(cntct_date,1,10),'%c/%d/%Y') END AS cntct_date,
    DATE_DIFF('month',
      CASE WHEN STRPOS(Term_start_date,'-')> 0 THEN CAST(SUBSTRING(Term_start_date,1,10) AS DATE)
        ELSE date_parse(SUBSTRING(Term_start_date,1,10),'%c/%d/%Y') END,
      CASE WHEN STRPOS(Term_end_date,'-')> 0 THEN CAST(SUBSTRING(Term_end_date,1,10) AS DATE)
        ELSE date_parse(SUBSTRING(Term_end_date,1,10),'%c/%d/%Y')END
    ) AS term_date_diff,
    x_offer_versn_desc,
    c_creatv_versn,
    enroll_status,
    service_type,
    concat(i_vin_first_9,i_vin_last_8) AS vin,
    n_cmpgn_seg,
    i_cmpgn,
    upper(N_brnd) as brand
  FROM service_marketing_reporting.uconnect_gsdp_cntct_hist
  WHERE TRIM(term_start_date)> ''
) 
, demodata as
(
  select 
    u.i_consmr
    , concat(u.i_vin_first_9, u.i_vin_last_8) as vin
    , c_persn_sex_1
    , demosex.x_colm_val_desc as N_PERSN_SEX_1
    , c_adlt_age
    , c_martl_stat
    , demomaritan.x_colm_val_desc as N_MARTL_STAT
    , demoedlev.x_colm_val_desc as N_EDUC
    , demoocc.x_colm_val_desc as N_OCCPTN
    , demohhi.x_colm_val_desc as N_HSHLD_INC_BAND
	, demohhcat.x_colm_val_desc as C_HSHLD_CATGY_TYP
  from service_marketing_reporting.uconnect_gsdp_cntct_hist u
  inner join fca_stg_prd.cms_cons_demo_info demo on u.i_consmr = demo.i_consmr
  left join fca_src_prd.cms_cms_mstr_cd_demo demosex on trim(demosex.x_colm_val) = trim(demo.c_persn_sex_1) and trim(demosex.N_COLM) = 'C_PERSN_SEX_1'
  left join fca_src_prd.cms_cms_mstr_cd_demo demomaritan on trim(demomaritan.x_colm_val) = trim(demo.c_martl_stat) and trim(demomaritan.N_COLM) = 'C_MARTL_STAT'
  left join fca_src_prd.cms_cms_mstr_cd_demo demoedlev on trim(demoedlev.x_colm_val) = trim(demo.C_EDUC) and trim(demoedlev.N_COLM) = 'C_EDUC'
  left join fca_src_prd.cms_cms_mstr_cd_demo demoocc on trim(demoocc.x_colm_val) = trim(demo.C_OCCPTN) and trim(demoocc.N_COLM) = 'C_OCCPTN'
  left join fca_src_prd.cms_cms_mstr_cd_demo demohhi on trim(demohhi.x_colm_val) = trim(demo.A_HSHLD_INC_BAND) and trim(demohhi.N_COLM) = 'A_HSHLD_INC_BAND'
  left join fca_src_prd.cms_cms_mstr_cd_demo demohhcat on trim(demohhcat.x_colm_val) = trim(demo.C_HSHLD_CATGY_TYP) and trim(demohhcat.N_COLM) = 'C_HSHLD_CATGY_TYP'
)
SELECT 
  YEAR(u.cntct_date) Contact_date_year,
  MONTH(u.cntct_date) Contact_date_month,--Cadence based on the contact date
  x_offer_versn_desc,
  brand, demodata.N_PERSN_SEX_1
, demodata.c_adlt_age
, demodata.N_MARTL_STAT
, demodata.N_EDUC
, demodata.N_OCCPTN
, demodata.N_HSHLD_INC_BAND
, demodata.C_HSHLD_CATGY_TYP,
  COUNT(DISTINCT u.vin) vinCount,
  COUNT(DISTINCT CASE WHEN u.cntct_date < CAST(SUBSTRING(sus.termstartdate,1,10) AS DATE) AND sus.servicetype = 'Optional' THEN u.vin END) attribution,
  CAST(COUNT(DISTINCT CASE WHEN u.cntct_date < CAST(SUBSTRING(sus.termstartdate,1,10) AS DATE) AND sus.servicetype = 'Optional' THEN u.vin END) AS DOUBLE
  )/ CAST(COUNT(DISTINCT u.vin) AS DOUBLE) attributionRate
FROM
  u LEFT
JOIN
  fca_src_prd.sf_gsdp_ignite_v_subscription sus
  ON u.vin = sus.vin
left join demodata on u.vin = demodata.vin
WHERE
  u.i_cmpgn = '9098'--winback campaign filter
  and u.x_offer_versn_desc in ('Lapse Prompt', 'LAPSE REMINDER', 'Lapse Prompt 6 or more')
GROUP BY
  YEAR(u.cntct_date),
  MONTH(u.cntct_date), x_offer_versn_desc,
  brand, demodata.N_PERSN_SEX_1
, demodata.c_adlt_age
, demodata.N_MARTL_STAT
, demodata.N_EDUC
, demodata.N_OCCPTN
, demodata.N_HSHLD_INC_BAND
, demodata.C_HSHLD_CATGY_TYP
ORDER BY
  YEAR(u.cntct_date),
  MONTH(u.cntct_date), x_offer_versn_desc,
  brand, demodata.N_PERSN_SEX_1
, demodata.c_adlt_age
, demodata.N_MARTL_STAT
, demodata.N_EDUC
, demodata.N_OCCPTN
, demodata.N_HSHLD_INC_BAND
, demodata.C_HSHLD_CATGY_TYP