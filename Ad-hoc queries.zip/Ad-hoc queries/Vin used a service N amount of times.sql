with carpark as (
  SELECT 
    concat(sc.i_vin_first_9,sc.i_vin_last_8) Vin
  FROM
    fca_stg_prd.cms_consmvhclownshp ow 
  INNER JOIN
    fca_stg_prd.cms_cms_vhcl_sales_cd sc
    ON concat(ow.i_vin_first_9,ow.i_vin_last_8) = concat(sc.i_vin_first_9,sc.i_vin_last_8) 
  INNER JOIN
    Campaign_stage_uconnect.vhr_tbm_vins vhr
    ON concat(ow.i_vin_first_9,ow.i_vin_last_8) = vhr.i_vin
  WHERE
    sc.c_vhcl_sales IN('RTM') 
    AND c_sdp = 'IGNITE'
    and ow.l_new_vhcl = 'NEW'
    )
, VinServUse as(
select carpark.Vin, serv.service, count(0) usagecount
from carpark
inner join fca_src_prd.sf_gsdp_ignite_v_subscription subs
  on carpark.Vin = subs.vin
inner join fca_src_prd.sf_gsdp_ignite_v_vehicleprofile_servicecapabilities_historical serv
  on subs.vin = serv.vin
where servicetype in ('Optional','Standard')
  and (productdisplayname like '%Navigation%' or productdisplayname like '%Assistance%')
  and productdisplayname not like '%Internal%'
group by carpark.Vin, serv.service)
select service, usagecount, count(distinct vin) as vinusage
from VinServUse
group by service, usagecount
order by service, usagecount